# Images ext
image = [".jpg", ".jpeg", ".jpe", ".png", ".svg"]

# Video ext
video = [".mp4", ".mov", ".mkv", ".gif", ".gifv", ".avi", ".wmv"]

# Installers ext
installers = [".exe", ".bat", ".sh", ".dmg", ".pkg", ".dll"]

# Document ext
document = [".pdf", ".doc", ".docx", ".pptx", ".ppt", ".xlsx", ".xls", ".xlsm", ".xlt",
            ".xltm", ".xltmx", ".xltmx", ".xlsx", ".txt"]

# Archive compressed ext
compressed = [".zip", ".7z", ".rar"]